<?php

declare(strict_types=1);

/**
 * Локальные секреты — не коммитить (см. .gitignore).
 */
return [
    'telegram_bot_token' => '8692456252:AAHZtDZDxZwEosNpnyohC80lM20dATspm5Q',
];
